
XSS AI BOT - Manual Installation

1. Create a virtual environment:
   python3 -m venv venv
   source venv/bin/activate

2. Install requirements:
   pip install -r requirements.txt
   playwright install

3. If offline and using a custom browser:
   export PLAYWRIGHT_BROWSERS_PATH=~/.cache/ms-playwright
   export PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1

4. Run the bot:
   python xss_bot_enhanced.py
